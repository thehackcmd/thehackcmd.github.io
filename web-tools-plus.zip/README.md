# Web Tools+

A collection of fully client-side web utilities that run directly in the browser.
Designed for GitHub Pages and educational use.

## Tools Included

- Internet Archive Browser
- Reader Mode
- Universal Media Player
- JSON Formatter
- Base64 Encoder / Decoder
- Password Generator
- Markdown Previewer
- URL Encoder / Decoder

## Hosting

Upload all files to a GitHub repository and enable GitHub Pages on the main branch.

## Notes

- No backend required
- No executables
- No paywall or access restriction bypassing
- Educational and experimental project
